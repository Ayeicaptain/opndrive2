export interface Notification {
  instance_id: string;
  title: string;
  message: string;
  is_read: string;
  created_at: string;
}
