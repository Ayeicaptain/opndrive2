export { DetailsSidebar } from './details-sidebar';
export { MobileDetailsDialog } from './mobile-details-dialog';
export { DetailsManager } from './details-manager';
