'use client';

import React from 'react';
import { OperationsModal } from './operations-modal';

export const UploadCard: React.FC = () => {
  return <OperationsModal />;
};
