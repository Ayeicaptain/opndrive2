/**
 * SEO Utilities
 * Export all SEO-related functions
 */

export * from './config';
export * from './structured-data';
