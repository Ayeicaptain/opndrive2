'use client';

import FAQSection from '@/features/landing-page/components/faq-section';

export function BlogFAQSection() {
  return (
    <div className="-mx-4 sm:-mx-6 lg:-mx-8">
      <FAQSection />
    </div>
  );
}
