# S3 API Wrapper

A lightweight, modular TypeScript wrapper around AWS S3, providing a pluggable
and extendable interface for interacting with S3-compatible object storage.
